from django.contrib import admin
from .models import AboutUs, Feature, FAQ

admin.site.register(AboutUs)
admin.site.register(Feature)
admin.site.register(FAQ)